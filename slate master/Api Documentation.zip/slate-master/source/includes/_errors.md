# Response Info

>Response Formate 

```Response

  {
    "status": "Error",
    "error": {
        "key": "409",
        "message": "Duplicate Request Reference"
    },
    "description": "Request Reference Must Be Unique. Use a Different Request Reference",
    "signature": "ea2ff59255a1f6f71610860f233c5de9287b4b125c3f41d5d1c25b1b08dbfd1d"
}

```

The Email Service API uses the following Error codes:


Error Code | Meaning
---------- | -------
200 | Ok -- The request has succeeded
202 | Accepted -- The request has been received but not yet acted upon
204 | No Content -- There is no content to send for this request, but the headers may be useful.
400 | Bad Request (Required) -- Your request is invalid.
401 | Unauthorized -- Your API key is wrong.
403 | Forbidden -- The client does not have access rights to the content.
404 | Not Found -- The server can not find requested resource.
405 | Method Not Allowed -- You tried to access a kitten with an invalid method.
410 | Gone -- The kitten requested has been removed from our servers.
409 | Conflict -- This response is sent when a request conflicts with the current state of the server.
422 | Unprocessable Entity (Validations) -- The request was well-formed but was unable to be followed due to semantic errors.
500 | Internal Server Error -- We had a problem with our server. Try again later.
503 | Service Unavailable -- The server is not ready to handle the request. or Service Not Available.
504 | Gateway Timeout -- This error response is given when the server is acting as a gateway and cannot get a response in time.

